<template>
  <div>{{ planInfo }}</div>
</template>

<script>
export default {
  name: "MainContent3",
  props: {
    planInfo: String,
  },
};
</script>

<style></style>
